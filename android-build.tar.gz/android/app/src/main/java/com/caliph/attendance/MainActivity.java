package com.caliph.attendance;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
